import 'package:drift/native.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:quran_hifz/core/database/database_providers.dart';
import 'package:quran_hifz/core/database/user_database.dart';
import 'package:quran_hifz/features/home/data/prayer_schedule.dart';
import 'package:quran_hifz/features/home/data/prayer_tracker_repository.dart';
import 'package:quran_hifz/features/home/presentation/home_dashboard_page.dart';
import 'package:quran_hifz/features/home/presentation/home_page.dart';
import 'package:quran_hifz/app/app_theme.dart';
import 'package:quran_hifz/features/settings/domain/app_preferences.dart';

void main() {
  testWidgets('home background and date hero follow every selected palette', (
    tester,
  ) async {
    final database = UserDatabase.forTesting(NativeDatabase.memory());
    addTearDown(database.close);
    for (final preference in [
      AppThemePreference.light,
      AppThemePreference.green,
      AppThemePreference.women,
      AppThemePreference.dark,
    ]) {
      await tester.pumpWidget(
        ProviderScope(
          overrides: [
            userDatabaseProvider.overrideWithValue(database),
            prayerScheduleProvider.overrideWith(
              (ref) async => throw StateError('No location'),
            ),
          ],
          child: MaterialApp(
            theme: appTheme(preference),
            home: const HomeDashboardPage(onMore: _noop, onPrayer: _noop),
          ),
        ),
      );
      await tester.pump(const Duration(milliseconds: 350));
      final scaffold = tester.widget<Scaffold>(find.byType(Scaffold).first);
      expect(
        scaffold.backgroundColor,
        appTheme(preference).colorScheme.surface,
      );
    }
  });
  testWidgets(
    'home shows prayer windows and tapping a row saves the salat check',
    (tester) async {
      tester.view.physicalSize = const Size(360, 780);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      final database = UserDatabase.forTesting(NativeDatabase.memory());
      addTearDown(database.close);
      final now = DateTime.now();
      final schedule = PrayerSchedule(
        location: 'Natore, Bangladesh',
        latitude: 24.42,
        longitude: 88.99,
        hijriDate: '3 Rabi al-Thani 1448 AH',
        sunrise: DateTime(now.year, now.month, now.day, 5, 32),
        sunset: DateTime(now.year, now.month, now.day, 18, 36),
        times: {
          'Fajr': DateTime(now.year, now.month, now.day, 4, 11),
          'Dhuhr': DateTime(now.year, now.month, now.day, 12, 4),
          'Asr': DateTime(now.year, now.month, now.day, 15, 48),
          'Maghrib': DateTime(now.year, now.month, now.day, 18, 36),
          'Isha': DateTime(now.year, now.month, now.day, 19, 52),
        },
        tomorrowFajr: DateTime(now.year, now.month, now.day + 1, 4, 11),
      );
      await tester.pumpWidget(
        ProviderScope(
          overrides: [
            userDatabaseProvider.overrideWithValue(database),
            prayerScheduleProvider.overrideWith((ref) async => schedule),
          ],
          child: const MaterialApp(
            home: HomeDashboardPage(onMore: _noop, onPrayer: _noop),
          ),
        ),
      );
      await tester.pumpAndSettle();

      expect(tester.takeException(), isNull);
      expect(find.text('নাটোর, বাংলাদেশ'), findsOneWidget);
      expect(find.text('পরবর্তী সলাত'), findsOneWidget);
      expect(find.textContaining('০৪:১১ – ০৫:৩২'), findsOneWidget);
      final list = tester.widget<ListView>(find.byType(ListView));
      expect(list.padding, const EdgeInsets.fromLTRB(12, 8, 12, 16));
      expect(
        tester.getSize(find.byKey(const ValueKey('prayer-row-Fajr'))).height,
        inInclusiveRange(44, 50),
      );
      final hero = tester.widget<Container>(
        find.byKey(const ValueKey('home-date-summary')),
      );
      final decoration = hero.decoration! as BoxDecoration;
      expect(decoration.gradient, isNull);
      expect(decoration.borderRadius, BorderRadius.circular(12));
      final prayerTime = tester.widget<Text>(
        find.textContaining('০৪:১১ – ০৫:৩২'),
      );
      expect(prayerTime.style?.fontSize, greaterThanOrEqualTo(14));
      expect(prayerTime.style?.fontWeight, FontWeight.w500);
      await tester.tap(find.text('ফজর').last);
      await tester.pumpAndSettle();
      final key =
          '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
      expect(
        await PrayerTrackerRepository(database).load(key),
        contains('Fajr'),
      );
      await tester.dragUntilVisible(
        find.text('সলাতের নিষিদ্ধ সময়'),
        find.byType(ListView),
        const Offset(0, -250),
      );
      expect(find.text('সকাল'), findsOneWidget);
      expect(find.text('দুপুর'), findsOneWidget);
      expect(find.text('সন্ধ্যা'), findsOneWidget);
      expect(find.byTooltip('নিষিদ্ধ সময়ের তথ্য'), findsOneWidget);
      expect(find.textContaining('আনুমানিক'), findsNothing);
      await tester.tap(find.byTooltip('নিষিদ্ধ সময়ের তথ্য'));
      await tester.pumpAndSettle();
      expect(find.textContaining('আনুমানিক'), findsOneWidget);
      await tester.tap(find.text('ঠিক আছে'));
      await tester.pumpAndSettle();
    },
  );
}

void _noop() {}
