import 'package:flutter_test/flutter_test.dart';
import 'package:quran_hifz/core/audio/background_audio.dart';

void main() {
  test(
    'background audio bootstrap delegates to injected initializer',
    () async {
      var calls = 0;

      await initializeBackgroundAudio(
        initializer: () async {
          calls++;
        },
      );

      expect(calls, 1);
    },
  );
}
