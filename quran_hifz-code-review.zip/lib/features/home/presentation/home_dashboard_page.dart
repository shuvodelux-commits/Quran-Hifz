import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/localization/app_locale_text.dart';
import '../../settings/application/app_preferences_controller.dart';
import '../../settings/domain/app_preferences.dart';
import '../application/prayer_tracker_providers.dart';
import '../data/bangla_calendar.dart';
import '../data/bangladesh_cities.dart';
import '../data/prayer_schedule.dart';
import 'home_page.dart' show prayerScheduleProvider;
import 'prayer_location_page.dart';

class HomeDashboardPage extends ConsumerStatefulWidget {
  const HomeDashboardPage({
    super.key,
    required this.onMore,
    required this.onPrayer,
  });
  final VoidCallback onMore;
  final VoidCallback onPrayer;

  @override
  ConsumerState<HomeDashboardPage> createState() => _HomeDashboardPageState();
}

class _HomeDashboardPageState extends ConsumerState<HomeDashboardPage> {
  Timer? _timer;
  DateTime _now = DateTime.now();

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      final next = DateTime.now();
      if (_dateKey(next) != _dateKey(_now))
        ref.invalidate(prayerScheduleProvider);
      setState(() => _now = next);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final prayerState = ref.watch(prayerScheduleProvider);
    final language = ref.watch(appLanguageProvider);
    final schedule = prayerState.value;
    final dayKey = _dateKey(_now);
    final completed =
        ref.watch(dailyPrayerChecksProvider(dayKey)).value ?? <String>{};
    final next = schedule?.nextPrayer(_now);

    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.surface,
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: () async => ref.refresh(prayerScheduleProvider.future),
          child: ListView(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 16),
            children: [
              Row(
                children: [
                  IconButton(
                    tooltip: 'More',
                    onPressed: widget.onMore,
                    icon: Icon(
                      Icons.menu_rounded,
                      color: Theme.of(context).colorScheme.onSurface,
                    ),
                  ),
                  Expanded(
                    child: InkWell(
                      onTap: () => Navigator.of(context).push(
                        MaterialPageRoute<void>(
                          builder: (_) => const PrayerLocationPage(),
                        ),
                      ),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.location_on_outlined,
                                color: Theme.of(context).colorScheme.primary,
                                size: 17,
                              ),
                              const SizedBox(width: 3),
                              Flexible(
                                child: Text(
                                  _localizedLocation(
                                        schedule?.location,
                                        language,
                                      ) ??
                                      appText(language, 'অবস্থান', 'Location'),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    color: Theme.of(
                                      context,
                                    ).colorScheme.onSurface,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          Text(
                            schedule == null
                                ? appText(
                                    language,
                                    'আপনার এলাকার সলাতের সময়',
                                    'Prayer times for your location',
                                  )
                                : '${appText(language, 'কিবলা', 'Qibla')}: ${localDigits('${_qibla(schedule.latitude, schedule.longitude).round()}', language)}°',
                            style: TextStyle(
                              color: Theme.of(
                                context,
                              ).colorScheme.onSurfaceVariant,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  IconButton(
                    tooltip: 'Refresh prayer times',
                    onPressed: () => ref.invalidate(prayerScheduleProvider),
                    icon: Icon(
                      Icons.notifications_none_rounded,
                      color: Theme.of(context).colorScheme.onSurface,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              _DateHero(now: _now, schedule: schedule, language: language),
              const SizedBox(height: 8),
              _NextPrayerCard(
                next: next,
                now: _now,
                onTap: widget.onPrayer,
                language: language,
              ),
              const SizedBox(height: 8),
              _Panel(
                child: Column(
                  children: [
                    for (final name in [
                      'Fajr',
                      'Sunrise',
                      'Dhuhr',
                      'Asr',
                      'Maghrib',
                      'Isha',
                    ])
                      _PrayerRow(
                        name: name,
                        time: name == 'Sunrise'
                            ? schedule?.sunrise
                            : schedule?.times[name],
                        end: switch (name) {
                          'Fajr' => schedule?.sunrise,
                          'Dhuhr' => schedule?.times['Asr'],
                          'Asr' => schedule?.times['Maghrib'],
                          'Maghrib' => schedule?.times['Isha'],
                          'Isha' => schedule?.tomorrowFajr,
                          _ => null,
                        },
                        active: next?.name == name,
                        completed: completed.contains(name),
                        language: language,
                        onTap: name == 'Sunrise'
                            ? null
                            : () => _toggle(dayKey, name),
                      ),
                  ],
                ),
              ),
              if (prayerState.hasError)
                Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Text(
                    prayerState.error is StateError
                        ? (prayerState.error as StateError).message
                        : 'Location and internet access are needed for prayer times.',
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.error,
                      fontSize: 12,
                    ),
                  ),
                ),
              const SizedBox(height: 8),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: _Panel(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  language == AppLanguage.bangla
                                      ? 'সলাতের নিষিদ্ধ সময়'
                                      : 'Prohibited prayer times',
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w600,
                                    fontSize: 14,
                                  ),
                                ),
                              ),
                              IconButton(
                                tooltip: appText(
                                  language,
                                  'নিষিদ্ধ সময়ের তথ্য',
                                  'About prohibited times',
                                ),
                                visualDensity: VisualDensity.compact,
                                onPressed: () =>
                                    _showProhibitedTimesInfo(context, language),
                                icon: const Icon(Icons.info_outline_rounded),
                              ),
                            ],
                          ),
                          const Divider(height: 10),
                          _ProhibitedTimeRow(
                            label: appText(language, 'সকাল', 'Morning'),
                            value: _range(
                              schedule?.sunrise,
                              15,
                              language,
                              after: true,
                            ),
                          ),
                          _ProhibitedTimeRow(
                            label: appText(language, 'দুপুর', 'Noon'),
                            value: _range(
                              schedule?.times['Dhuhr'],
                              5,
                              language,
                            ),
                          ),
                          _ProhibitedTimeRow(
                            label: appText(language, 'সন্ধ্যা', 'Evening'),
                            value: _range(schedule?.sunset, 15, language),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _Panel(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                Icons.nights_stay_outlined,
                                color: Theme.of(context).colorScheme.primary,
                              ),
                              const SizedBox(width: 5),
                              Expanded(
                                child: Text(
                                  language == AppLanguage.bangla
                                      ? 'আজকের রোজা'
                                      : 'Fasting today',
                                  maxLines: 2,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w500,
                                    fontSize: 12,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Text(
                            appText(language, 'সেহরি শেষ', 'Suhur ends'),
                            style: TextStyle(
                              fontSize: 11,
                              color: Theme.of(
                                context,
                              ).colorScheme.onSurfaceVariant,
                            ),
                          ),
                          Text(
                            localClock(schedule?.times['Fajr'], language),
                            style: const TextStyle(fontWeight: FontWeight.w500),
                          ),
                          const Divider(height: 14),
                          Text(
                            appText(language, 'ইফতার', 'Iftar'),
                            style: TextStyle(
                              fontSize: 11,
                              color: Theme.of(
                                context,
                              ).colorScheme.onSurfaceVariant,
                            ),
                          ),
                          Text(
                            localClock(schedule?.times['Maghrib'], language),
                            style: const TextStyle(fontWeight: FontWeight.w500),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              _Panel(
                child: Row(
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.primaryContainer,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(
                        Icons.menu_book_rounded,
                        color: Theme.of(context).colorScheme.primary,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            language == AppLanguage.bangla
                                ? 'আজকের দোয়া'
                                : 'Today’s dua',
                            style: const TextStyle(fontWeight: FontWeight.w500),
                          ),
                          const SizedBox(height: 3),
                          const Text(
                            'رَبِّ زِدْنِي عِلْمًا',
                            style: TextStyle(fontSize: 21),
                          ),
                          Text(
                            appText(
                              language,
                              'হে আমার রব, আমার জ্ঞান বাড়িয়ে দিন। · সূরা ত্বহা ২০:১১৪',
                              'My Lord, increase me in knowledge. · Ta-Ha 20:114',
                            ),
                            style: TextStyle(
                              fontSize: 11,
                              color: Theme.of(
                                context,
                              ).colorScheme.onSurfaceVariant,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _toggle(String dayKey, String name) async {
    await toggleDailyPrayer(ref, dayKey, name);
  }

  Future<void> _showProhibitedTimesInfo(
    BuildContext context,
    AppLanguage language,
  ) {
    return showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(
          appText(language, 'নিষিদ্ধ সময় সম্পর্কে', 'About prohibited times'),
        ),
        content: Text(
          appText(
            language,
            'সময়গুলো আনুমানিক। আপনার স্থানীয় মসজিদের সময় অনুসরণ করুন।',
            'These times are approximate. Follow your local mosque timetable.',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: Text(appText(language, 'ঠিক আছে', 'OK')),
          ),
        ],
      ),
    );
  }
}

class _DateHero extends StatelessWidget {
  const _DateHero({
    required this.now,
    required this.schedule,
    required this.language,
  });
  final DateTime now;
  final PrayerSchedule? schedule;
  final AppLanguage language;
  @override
  Widget build(BuildContext context) => Container(
    key: const ValueKey('home-date-summary'),
    padding: const EdgeInsets.fromLTRB(10, 12, 10, 10),
    decoration: BoxDecoration(
      color: Theme.of(context).colorScheme.primary,
      borderRadius: BorderRadius.circular(12),
    ),
    child: Column(
      children: [
        Row(
          children: [
            _DateColumn(
              icon: Icons.nights_stay_outlined,
              value: localHijriDate(
                schedule?.hijriDateAt(now) ?? '—',
                language,
              ),
              label: appText(language, 'হিজরি', 'Hijri'),
            ),
            const _HeroDivider(),
            _DateColumn(
              icon: Icons.calendar_today_outlined,
              value: localGregorianDate(now, language),
              label: appText(language, 'গ্রেগরিয়ান', 'Gregorian'),
            ),
            const _HeroDivider(),
            _DateColumn(
              icon: Icons.auto_awesome_outlined,
              value: banglaCalendarDate(
                now,
                english: language == AppLanguage.english,
              ),
              label: appText(language, 'বাংলা', 'Bangla'),
            ),
          ],
        ),
        Divider(
          color: Theme.of(
            context,
          ).colorScheme.onPrimary.withValues(alpha: 0.35),
          height: 14,
        ),
        Row(
          children: [
            Expanded(
              child: _SunLine(
                icon: Icons.wb_sunny_outlined,
                label: appText(language, 'সূর্যোদয়', 'Sunrise'),
                time: schedule?.sunrise,
                language: language,
              ),
            ),
            Container(
              width: 1,
              height: 30,
              color: Theme.of(
                context,
              ).colorScheme.onPrimary.withValues(alpha: 0.4),
            ),
            Expanded(
              child: _SunLine(
                icon: Icons.wb_twilight_outlined,
                label: appText(language, 'সূর্যাস্ত', 'Sunset'),
                time: schedule?.sunset,
                language: language,
              ),
            ),
          ],
        ),
      ],
    ),
  );
}

class _HeroDivider extends StatelessWidget {
  const _HeroDivider();
  @override
  Widget build(BuildContext context) => Container(
    width: 1,
    height: 60,
    color: Theme.of(context).colorScheme.onPrimary.withValues(alpha: 0.35),
  );
}

class _DateColumn extends StatelessWidget {
  const _DateColumn({
    required this.icon,
    required this.value,
    required this.label,
  });
  final IconData icon;
  final String value;
  final String label;
  @override
  Widget build(BuildContext context) => Expanded(
    child: Column(
      children: [
        Icon(icon, color: Theme.of(context).colorScheme.onPrimary, size: 18),
        const SizedBox(height: 3),
        Text(
          value,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          textAlign: TextAlign.center,
          style: TextStyle(
            color: Theme.of(context).colorScheme.onPrimary,
            fontSize: 12,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 1),
        Text(
          label,
          style: TextStyle(
            color: Theme.of(
              context,
            ).colorScheme.onPrimary.withValues(alpha: 0.78),
            fontSize: 10,
          ),
        ),
      ],
    ),
  );
}

class _SunLine extends StatelessWidget {
  const _SunLine({
    required this.icon,
    required this.label,
    required this.time,
    required this.language,
  });
  final IconData icon;
  final String label;
  final DateTime? time;
  final AppLanguage language;
  @override
  Widget build(BuildContext context) => Row(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      Icon(icon, color: Theme.of(context).colorScheme.onPrimary, size: 20),
      const SizedBox(width: 5),
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(
              color: Theme.of(
                context,
              ).colorScheme.onPrimary.withValues(alpha: 0.78),
              fontSize: 11,
            ),
          ),
          Text(
            localClock(time, language),
            style: TextStyle(
              color: Theme.of(context).colorScheme.onPrimary,
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    ],
  );
}

class _NextPrayerCard extends StatelessWidget {
  const _NextPrayerCard({
    required this.next,
    required this.now,
    required this.onTap,
    required this.language,
  });
  final ({String name, DateTime time})? next;
  final DateTime now;
  final VoidCallback onTap;
  final AppLanguage language;
  @override
  Widget build(BuildContext context) {
    final remaining = next?.time.difference(now);
    return _Panel(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Theme.of(context).colorScheme.primaryContainer,
              ),
              child: Icon(
                Icons.mosque_rounded,
                color: Theme.of(context).colorScheme.primary,
                size: 24,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    appText(language, 'পরবর্তী সলাত', 'Next Prayer'),
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.primary,
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  Text(
                    next == null ? '—' : localPrayerName(next!.name, language),
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.onSurface,
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  Text(
                    localClock(next?.time, language),
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.primary,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              width: 1,
              height: 44,
              color: Theme.of(context).colorScheme.outlineVariant,
            ),
            const SizedBox(width: 10),
            Column(
              children: [
                Text(
                  appText(language, 'শুরু হতে বাকি', 'Starts in'),
                  style: const TextStyle(fontSize: 11),
                ),
                Text(
                  remaining == null ? '—' : localCountdown(remaining, language),
                  style: TextStyle(
                    color: Theme.of(context).colorScheme.primary,
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            Icon(
              Icons.chevron_right_rounded,
              color: Theme.of(context).colorScheme.primary,
              size: 18,
            ),
          ],
        ),
      ),
    );
  }
}

class _PrayerRow extends StatelessWidget {
  const _PrayerRow({
    required this.name,
    required this.time,
    this.end,
    required this.active,
    required this.completed,
    required this.language,
    this.onTap,
  });
  final String name;
  final DateTime? time;
  final DateTime? end;
  final bool active;
  final bool completed;
  final AppLanguage language;
  final VoidCallback? onTap;
  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap,
    child: Container(
      key: ValueKey('prayer-row-$name'),
      constraints: const BoxConstraints(minHeight: 48, maxHeight: 48),
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: Theme.of(context).colorScheme.outlineVariant,
          ),
        ),
        color: active
            ? Theme.of(
                context,
              ).colorScheme.primaryContainer.withValues(alpha: 0.5)
            : null,
      ),
      child: Row(
        children: [
          Icon(
            name == 'Isha'
                ? Icons.nights_stay_outlined
                : name == 'Sunrise'
                ? Icons.wb_sunny_outlined
                : Icons.mosque_outlined,
            size: 20,
            color: active
                ? Theme.of(context).colorScheme.primary
                : Theme.of(context).colorScheme.onSurfaceVariant,
          ),
          const SizedBox(width: 8),
          SizedBox(
            width: 82,
            child: Text(
              localPrayerName(name, language),
              style: TextStyle(
                color: active
                    ? Theme.of(context).colorScheme.primary
                    : Theme.of(context).colorScheme.onSurface,
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          Expanded(
            child: Text(
              end == null
                  ? localClock(time, language)
                  : '${localClock(time, language)} – ${localClock(end, language)}',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: end == null ? 16 : 14,
                color: active
                    ? Theme.of(context).colorScheme.primary
                    : Theme.of(context).colorScheme.onSurface,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          const SizedBox(width: 8),
          Icon(
            onTap == null
                ? Icons.remove_circle_outline
                : completed
                ? Icons.check_circle_rounded
                : Icons.radio_button_unchecked_rounded,
            color: onTap == null
                ? Theme.of(context).colorScheme.outline
                : completed
                ? Theme.of(context).colorScheme.primary
                : Theme.of(context).colorScheme.outline,
            size: 20,
          ),
        ],
      ),
    ),
  );
}

class _Panel extends StatelessWidget {
  const _Panel({required this.child});
  final Widget child;
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(10),
    decoration: BoxDecoration(
      color: Theme.of(context).colorScheme.surfaceContainerLow,
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
    ),
    child: child,
  );
}

class _ProhibitedTimeRow extends StatelessWidget {
  const _ProhibitedTimeRow({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 2),
    child: Row(
      children: [
        Text(
          label,
          style: TextStyle(
            color: Theme.of(context).colorScheme.onSurfaceVariant,
            fontSize: 12,
          ),
        ),
        Text(
          ':',
          style: TextStyle(
            color: Theme.of(context).colorScheme.onSurfaceVariant,
            fontSize: 12,
          ),
        ),
        const SizedBox(width: 4),
        Expanded(
          child: Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.end,
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
          ),
        ),
      ],
    ),
  );
}

String _dateKey(DateTime date) =>
    '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';

String? _localizedLocation(String? location, AppLanguage language) {
  if (location == null || language == AppLanguage.english) return location;
  final cityName = location.split(',').first.trim().toLowerCase();
  for (final city in bangladeshCities) {
    if (city.name.toLowerCase() == cityName) return '${city.bnName}, বাংলাদেশ';
  }
  return location.replaceAll('Bangladesh', 'বাংলাদেশ');
}

String _range(
  DateTime? end,
  int minutes,
  AppLanguage language, {
  bool after = false,
}) {
  if (end == null) return '—';
  return after
      ? '${localClock(end, language)}–${localClock(end.add(Duration(minutes: minutes)), language)}'
      : '${localClock(end.subtract(Duration(minutes: minutes)), language)}–${localClock(end, language)}';
}

double _qibla(double latitude, double longitude) {
  final lat = latitude * math.pi / 180;
  final delta = (39.8262 - longitude) * math.pi / 180;
  final targetLat = 21.4225 * math.pi / 180;
  return (math.atan2(
                math.sin(delta),
                math.cos(lat) * math.tan(targetLat) -
                    math.sin(lat) * math.cos(delta),
              ) *
              180 /
              math.pi +
          360) %
      360;
}
