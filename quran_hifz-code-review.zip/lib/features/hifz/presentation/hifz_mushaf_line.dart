import 'package:flutter/material.dart';
import '../../quran/domain/quran_font_preference.dart';
import '../../quran/presentation/widgets/quran_word_view.dart';
import '../application/hifz_text_layout.dart';
import '../domain/hifz_session.dart';

class HifzMushafLine extends StatelessWidget {
  const HifzMushafLine({
    super.key,
    required this.words,
    required this.centered,
    required this.font,
    required this.fontSize,
    required this.lineHeight,
    required this.selectedAyahs,
    required this.activeAyahKey,
    this.onAyahSelected,
    this.onWordTap,
    this.onWordLongPress,
  });

  final List<HifzLineWord> words;
  final bool centered;
  final QuranFontPreference font;
  final double fontSize;
  final double lineHeight;
  final Set<AyahRef> selectedAyahs;
  final String? activeAyahKey;
  final ValueChanged<AyahRef>? onAyahSelected;
  final void Function(HifzLineWord lineWord)? onWordTap;
  final void Function(HifzLineWord lineWord)? onWordLongPress;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: ConstrainedBox(
        constraints: BoxConstraints(
          minHeight: MediaQuery.textScalerOf(
            context,
          ).scale(fontSize * lineHeight),
        ),
        child: Wrap(
          alignment: centered ? WrapAlignment.center : WrapAlignment.start,
          crossAxisAlignment: WrapCrossAlignment.center,
          spacing: 4,
          runSpacing: fontSize * (lineHeight - 1),
          children: [
            for (final word in words)
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  HifzMushafWord(
                    key: ValueKey(
                      'hifz-word-${word.ayah.key}:${word.word.position}',
                    ),
                    lineWord: word,
                    font: font,
                    fontSize: fontSize,
                    lineHeight: lineHeight,
                    isActiveAyah: false,
                    contentPadding: EdgeInsets.zero,
                    onTap: onWordTap == null ? null : () => onWordTap!(word),
                    onLongPress: onWordLongPress == null
                        ? null
                        : () => onWordLongPress!(word),
                  ),
                  if (word.endsAyah) ...[
                    const SizedBox(width: 2),
                    HifzAyahMarker(
                      ayahNumber: word.ayah.ayahNumber,
                      ayahKey: word.ayah.key,
                      fontSize: fontSize,
                      selected: selectedAyahs.contains(
                        AyahRef(
                          surahNumber: word.ayah.surahNumber,
                          ayahNumber: word.ayah.ayahNumber,
                        ),
                      ),
                      active: false,
                      onTap: onAyahSelected == null
                          ? null
                          : () => onAyahSelected!(
                              AyahRef(
                                surahNumber: word.ayah.surahNumber,
                                ayahNumber: word.ayah.ayahNumber,
                              ),
                            ),
                    ),
                  ],
                ],
              ),
          ],
        ),
      ),
    );
  }
}

class HifzMushafWord extends StatelessWidget {
  const HifzMushafWord({
    super.key,
    required this.lineWord,
    required this.font,
    required this.fontSize,
    required this.lineHeight,
    required this.isActiveAyah,
    this.contentPadding = EdgeInsets.zero,
    this.onTap,
    this.onLongPress,
  });

  final HifzLineWord lineWord;
  final QuranFontPreference font;
  final double fontSize;
  final double lineHeight;
  final bool isActiveAyah;
  final EdgeInsetsGeometry contentPadding;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;

  @override
  Widget build(BuildContext context) {
    return QuranWordView(
      word: lineWord.word,
      isActive: isActiveAyah,
      playbackAyahKey: lineWord.ayah.key,
      onTap: onTap,
      onLongPress: onLongPress,
      typographyFont: font,
      typographyFontSize: fontSize,
      typographyLineHeight: lineHeight,
      contentPadding: contentPadding,
    );
  }
}

class HifzAyahMarker extends StatelessWidget {
  const HifzAyahMarker({
    super.key,
    required this.ayahNumber,
    required this.ayahKey,
    required this.fontSize,
    required this.selected,
    required this.active,
    this.onTap,
  });

  final int ayahNumber;
  final String ayahKey;
  final double fontSize;
  final bool selected;
  final bool active;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final color = active || selected ? scheme.primary : scheme.onSurfaceVariant;
    final scaledSize = MediaQuery.textScalerOf(context).scale(fontSize);
    return Semantics(
      button: true,
      label: 'Select ayah $ayahNumber',
      child: InkWell(
        key: ValueKey('hifz-ayah-marker-$ayahKey'),
        onTap: onTap,
        child: SizedBox.square(
          dimension: scaledSize * .92,
          child: Center(
            child: Text(
              _arabicIndic(ayahNumber),
              textDirection: TextDirection.ltr,
              style: TextStyle(
                color: color,
                fontFamily: 'hafs',
                package: 'flutter_quran',
                fontSize: fontSize * .92,
                height: 1,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

String _arabicIndic(int number) => number
    .toString()
    .split('')
    .map((digit) => String.fromCharCode(0x0660 + int.parse(digit)))
    .join();
