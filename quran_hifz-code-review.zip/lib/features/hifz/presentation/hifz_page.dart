import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../audio/application/audio_providers.dart';
import '../../quran/application/quran_providers.dart';
import '../../quran/application/reader_audio_actions.dart';
import '../../quran/domain/quran_ayah.dart';
import '../../quran/domain/quran_page_window.dart';
import '../../quran/domain/quran_surah.dart';
import '../../quran/domain/quran_word.dart';
import '../../reciters/application/reciter_catalog_controller.dart';
import '../../study/application/study_providers.dart';
import '../../study/domain/bookmark.dart';
import '../../study/presentation/word_details_sheet.dart';
import '../application/hifz_session_controller.dart';
import '../domain/hifz_session.dart';
import 'hifz_active_player.dart';
import 'hifz_appearance_sheet.dart';
import 'hifz_mushaf_surface.dart';
import 'hifz_pattern_controls.dart';
import 'hifz_setup_sheet.dart';
import 'hifz_system_ui.dart';

class HifzPage extends ConsumerStatefulWidget {
  const HifzPage({super.key, this.initialPage = 1})
    : assert(initialPage >= 1 && initialPage <= 604);

  final int initialPage;

  @override
  ConsumerState<HifzPage> createState() => _HifzPageState();
}

class _HifzPageState extends ConsumerState<HifzPage> {
  late final HifzSystemUi _systemUi;
  final ScrollController _mushafScrollController = ScrollController();
  bool _controlsVisible = true;
  int _selectedSurahNumber = 1;
  late int _selectedPage;
  AyahRef? _rangeStartAyah;
  AyahRef? _rangeEndAyah;
  Future<QuranPageWindow>? _pageFuture;
  String? _lastFollowedAyahKey;
  HifzPatternSelection _pattern = const HifzPatternSelection(
    ayahRepeatCount: 5,
    combinedRepeatCount: 3,
    finalRangeRepeatCount: 3,
  );

  @override
  void initState() {
    super.initState();
    _systemUi = ref.read(hifzSystemUiProvider);
    _selectedPage = widget.initialPage;
    _pageFuture = _loadPage(_selectedPage);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) unawaited(_systemUi.enter());
    });
  }

  @override
  void dispose() {
    unawaited(_systemUi.restore());
    _mushafScrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final surahs = ref.watch(quranSurahListProvider);
    final session = ref.watch(hifzSessionControllerProvider);
    final activeAyahKey = ref.watch(activeAyahPlaybackKeyProvider);
    final audio = ref.watch(quranAudioControllerProvider);

    ref.listen<String?>(activeAyahPlaybackKeyProvider, (previous, next) {
      if (next == null || next == previous) return;
      unawaited(_followActiveAyah(next));
    });
    ref.listen<HifzSessionState>(hifzSessionControllerProvider, (
      previous,
      next,
    ) {
      final config = next.config;
      if (config == null || identical(previous?.config, config)) return;
      unawaited(_alignToSession(config));
    });

    return surahs.when(
      loading: () =>
          const Scaffold(body: Center(child: CircularProgressIndicator())),
      error: (_, __) => Scaffold(
        body: Center(
          child: FilledButton(
            onPressed: () => ref.invalidate(quranSurahListProvider),
            child: const Text('Retry Quran library'),
          ),
        ),
      ),
      data: (items) {
        if (items.isEmpty) {
          return const Scaffold(
            body: Center(child: Text('Quran library is unavailable.')),
          );
        }
        final selectedSurah = _findSurah(items, _selectedSurahNumber);
        final playing =
            session.status == HifzSessionStatus.running ||
            session.status == HifzSessionStatus.paused;

        return Scaffold(
          body: Column(
            children: [
              Visibility(
                key: const ValueKey('hifz-top-controls-visibility'),
                visible: _controlsVisible,
                maintainAnimation: true,
                maintainState: true,
                maintainSize: true,
                child: Material(
                  key: const ValueKey('hifz-top-controls'),
                  color: Theme.of(context).colorScheme.surface,
                  elevation: 2,
                  child: SafeArea(
                    bottom: false,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Row(
                          children: [
                            IconButton(
                              key: const ValueKey('hifz-close'),
                              tooltip: 'Close Hifz',
                              onPressed: () => Navigator.of(context).maybePop(),
                              icon: const Icon(Icons.close_rounded),
                            ),
                            const Expanded(
                              child: Text(
                                'Hifz',
                                textAlign: TextAlign.center,
                                style: TextStyle(fontWeight: FontWeight.w700),
                              ),
                            ),
                            IconButton(
                              tooltip: 'Hifz settings',
                              onPressed: _openSettings,
                              icon: const Icon(Icons.settings_outlined),
                            ),
                          ],
                        ),
                        if (!playing)
                          _CompactSurahSelector(
                            surah: selectedSurah,
                            page: _selectedPage,
                            onTap: () => _showSurahPicker(items, selectedSurah),
                          ),
                      ],
                    ),
                  ),
                ),
              ),
              Expanded(
                child: GestureDetector(
                  key: const ValueKey('hifz-reading-gesture'),
                  behavior: HitTestBehavior.translucent,
                  onTap: _controlsVisible ? _hideControls : _showControls,
                  onHorizontalDragEnd: _handlePageSwipe,
                  onVerticalDragUpdate: _controlsVisible
                      ? null
                      : _scrollCleanSurface,
                  child: SafeArea(
                    top: false,
                    bottom: false,
                    child: Center(
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 840),
                        child: FutureBuilder<QuranPageWindow>(
                          future: _pageFuture,
                          builder: (context, snapshot) {
                            if (snapshot.connectionState !=
                                ConnectionState.done) {
                              return const Center(
                                child: CircularProgressIndicator(),
                              );
                            }
                            if (snapshot.hasError || snapshot.data == null) {
                              return Center(
                                child: FilledButton(
                                  onPressed: _reloadPage,
                                  child: const Text('Retry page'),
                                ),
                              );
                            }
                            return HifzMushafSurface(
                              key: ValueKey('hifz-mushaf-$_selectedPage'),
                              surah: selectedSurah,
                              surahs: items,
                              window: snapshot.data!,
                              scrollController: _mushafScrollController,
                              selectedStartAyah: _rangeStartAyah,
                              selectedEndAyah: _rangeEndAyah,
                              activeAyahKey: playing ? activeAyahKey : null,
                              onAyahSelected: playing ? null : _selectRangeAyah,
                              onWordTap: (ayah, word) =>
                                  unawaited(_playWord(ayah, word)),
                              onWordLongPress: _showWordDetails,
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              Visibility(
                key: const ValueKey('hifz-bottom-controls-visibility'),
                visible: _controlsVisible,
                maintainAnimation: true,
                maintainState: true,
                maintainSize: true,
                child: Material(
                  key: const ValueKey('hifz-bottom-controls'),
                  color: Theme.of(context).colorScheme.surface,
                  elevation: 4,
                  child: SafeArea(
                    top: false,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (playing)
                          HifzActivePlayer(
                            surah: selectedSurah,
                            session: session,
                            audio: audio,
                            onPause: () => unawaited(
                              ref
                                  .read(hifzSessionControllerProvider.notifier)
                                  .pause(),
                            ),
                            onResume: () => unawaited(
                              ref
                                  .read(hifzSessionControllerProvider.notifier)
                                  .resume(),
                            ),
                            onStop: () => unawaited(
                              ref
                                  .read(hifzSessionControllerProvider.notifier)
                                  .stop(),
                            ),
                          ),
                        _HifzPageControls(
                          page: _selectedPage,
                          showTools: !playing,
                          onPrevious: _selectedPage > 1
                              ? () => _turnPage(_selectedPage - 1)
                              : null,
                          onTools: playing
                              ? null
                              : () => _openSetupSheet(selectedSurah),
                          onNext: _selectedPage < 604
                              ? () => _turnPage(_selectedPage + 1)
                              : null,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _hideControls() {
    if (!_controlsVisible) return;
    setState(() => _controlsVisible = false);
  }

  void _showControls() {
    if (_controlsVisible) return;
    setState(() => _controlsVisible = true);
  }

  void _handlePageSwipe(DragEndDetails details) {
    final velocity = details.primaryVelocity ?? 0;
    if (velocity < -250 && _selectedPage < 604) {
      _turnPage(_selectedPage + 1);
    } else if (velocity > 250 && _selectedPage > 1) {
      _turnPage(_selectedPage - 1);
    }
  }

  void _scrollCleanSurface(DragUpdateDetails details) {
    if (!_mushafScrollController.hasClients) return;
    final position = _mushafScrollController.position;
    final next = (position.pixels - details.delta.dy).clamp(
      position.minScrollExtent,
      position.maxScrollExtent,
    );
    _mushafScrollController.jumpTo(next.toDouble());
  }

  void _openSettings() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => const HifzAppearanceSheet(),
    );
  }

  Future<void> _showSurahPicker(
    List<QuranSurahSummary> surahs,
    QuranSurahSummary selected,
  ) {
    return showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (sheetContext) => SafeArea(
        top: false,
        child: Center(
          heightFactor: 1,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 560),
            child: SizedBox(
              height: MediaQuery.sizeOf(sheetContext).height * 0.7,
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 4, 20, 8),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            'Choose Surah',
                            style: Theme.of(sheetContext).textTheme.titleLarge,
                          ),
                        ),
                        IconButton(
                          tooltip: 'Previous Mushaf page',
                          onPressed: _selectedPage > selected.pageStart
                              ? () {
                                  _turnPage(_selectedPage - 1);
                                  Navigator.of(sheetContext).pop();
                                }
                              : null,
                          icon: const Icon(Icons.chevron_right_rounded),
                        ),
                        Text('Page $_selectedPage'),
                        IconButton(
                          tooltip: 'Next Mushaf page',
                          onPressed: _selectedPage < selected.pageEnd
                              ? () {
                                  _turnPage(_selectedPage + 1);
                                  Navigator.of(sheetContext).pop();
                                }
                              : null,
                          icon: const Icon(Icons.chevron_left_rounded),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: ListView.builder(
                      itemCount: surahs.length,
                      itemBuilder: (context, index) {
                        final surah = surahs[index];
                        return ListTile(
                          key: ValueKey('hifz-surah-choice-${surah.number}'),
                          selected: surah.number == selected.number,
                          title: Text('${surah.number}. ${surah.nameEnglish}'),
                          subtitle: Text(surah.nameArabic),
                          trailing: surah.number == selected.number
                              ? const Icon(Icons.check_rounded)
                              : null,
                          onTap: () {
                            _selectSurah(surah);
                            Navigator.of(sheetContext).pop();
                          },
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _openSetupSheet(QuranSurahSummary surah) {
    return showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => StatefulBuilder(
        builder: (context, refreshSheet) => Consumer(
          builder: (context, ref, _) {
            final reciterSelected =
                ref
                    .watch(reciterCatalogControllerProvider)
                    .value
                    ?.selectedReciterId !=
                null;
            final sessionStatus = ref
                .watch(hifzSessionControllerProvider)
                .status;
            return HifzSetupSheet(
              surah: surah,
              startAyah: _rangeStartAyah?.ayahNumber,
              endAyah: _rangeEndAyah?.ayahNumber,
              pattern: _pattern,
              reciterSelected: reciterSelected,
              onStartRange: () =>
                  unawaited(_pickRangeStart(surah, refreshSheet)),
              onEndRange: _rangeStartAyah == null
                  ? null
                  : () => unawaited(_pickRangeEnd(surah, refreshSheet)),
              onPattern: () => unawaited(_pickPattern(surah, refreshSheet)),
              onAdvancedSettings: () {
                Navigator.of(sheetContext).pop();
                _openSettings();
              },
              onPlay: () {
                Navigator.of(sheetContext).pop();
                unawaited(_beginPlayback());
              },
              onClose: () => Navigator.of(sheetContext).pop(),
              onResumeSaved:
                  sessionStatus == HifzSessionStatus.stopped ||
                      sessionStatus == HifzSessionStatus.error
                  ? () {
                      Navigator.of(sheetContext).pop();
                      unawaited(_resumeSaved());
                    }
                  : null,
            );
          },
        ),
      ),
    );
  }

  Future<void> _pickRangeStart(
    QuranSurahSummary surah,
    StateSetter refreshSheet,
  ) async {
    final ayah = await _pickAyah(
      title: 'Start Range',
      minimum: 1,
      maximum: surah.ayahCount,
      selected: _rangeStartAyah?.ayahNumber,
    );
    if (!mounted || ayah == null) return;
    await _setRangeStart(ayah);
    if (mounted) refreshSheet(() {});
  }

  Future<void> _pickRangeEnd(
    QuranSurahSummary surah,
    StateSetter refreshSheet,
  ) async {
    final start = _rangeStartAyah;
    if (start == null) return;
    final ayah = await _pickAyah(
      title: 'End Range',
      minimum: start.ayahNumber,
      maximum: surah.ayahCount,
      selected: _rangeEndAyah?.ayahNumber,
    );
    if (!mounted || ayah == null) return;
    await _setRangeEnd(ayah);
    if (mounted) refreshSheet(() {});
  }

  Future<int?> _pickAyah({
    required String title,
    required int minimum,
    required int maximum,
    required int? selected,
  }) {
    return showModalBottomSheet<int>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (_) => HifzAyahPickerSheet(
        title: title,
        minimum: minimum,
        maximum: maximum,
        selected: selected,
      ),
    );
  }

  Future<void> _pickPattern(
    QuranSurahSummary surah,
    StateSetter refreshSheet,
  ) async {
    final result = await showModalBottomSheet<HifzPatternSelection>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (_) => HifzPatternSheet(
        surahNumber: surah.number,
        startAyah: _rangeStartAyah?.ayahNumber ?? 1,
        endAyah: _rangeEndAyah?.ayahNumber ?? _rangeStartAyah?.ayahNumber ?? 1,
        initialSelection: _pattern,
      ),
    );
    if (!mounted || result == null) return;
    setState(() => _pattern = result);
    refreshSheet(() {});
  }

  Future<void> _beginPlayback() async {
    final start = _rangeStartAyah;
    if (start == null) return;
    if (ref.read(reciterCatalogControllerProvider).value?.selectedReciterId ==
        null) {
      _showMessage('Choose a reciter in Advanced Settings before playing.');
      return;
    }
    await _startSession(
      HifzSessionConfig(
        start: start,
        end: _rangeEndAyah ?? start,
        preset: _pattern.toPreset(),
      ),
    );
  }

  Future<QuranPageWindow> _loadPage(int page) {
    return ref
        .read(quranRepositoryProvider)
        .loadPageWindow(
          page: page,
          translationResourceId: ref.read(quranTranslationResourceIdProvider),
        );
  }

  void _reloadPage() {
    setState(() => _pageFuture = _loadPage(_selectedPage));
  }

  void _selectSurah(QuranSurahSummary surah) {
    setState(() {
      _selectedSurahNumber = surah.number;
      _selectedPage = surah.pageStart;
      _rangeStartAyah = null;
      _rangeEndAyah = null;
      _lastFollowedAyahKey = null;
      _pageFuture = _loadPage(surah.pageStart);
    });
  }

  void _turnPage(int page) {
    if (page < 1 || page > 604 || page == _selectedPage) return;
    final pageFuture = _loadPage(page);
    setState(() {
      _selectedPage = page;
      _pageFuture = pageFuture;
    });
    if (_mushafScrollController.hasClients) {
      _mushafScrollController.jumpTo(0);
    }
    unawaited(
      pageFuture.then((window) {
        if (!mounted || _selectedPage != page || window.ayahs.isEmpty) return;
        final firstSurah = window.ayahs.first.surahNumber;
        if (firstSurah == _selectedSurahNumber) return;
        setState(() => _selectedSurahNumber = firstSurah);
      }),
    );
  }

  void _selectRangeAyah(AyahRef ayah) {
    setState(() {
      final start = _rangeStartAyah;
      _selectedSurahNumber = ayah.surahNumber;
      if (start == null ||
          _rangeEndAyah != null ||
          start.surahNumber != ayah.surahNumber) {
        _rangeStartAyah = ayah;
        _rangeEndAyah = null;
        return;
      }
      if (ayah.ayahNumber < start.ayahNumber) {
        _rangeStartAyah = ayah;
        _rangeEndAyah = null;
        return;
      }
      _rangeEndAyah = ayah;
    });
  }

  Future<void> _setRangeStart(int ayahNumber) async {
    setState(() {
      _rangeStartAyah = AyahRef(
        surahNumber: _selectedSurahNumber,
        ayahNumber: ayahNumber,
      );
      if (_rangeEndAyah != null && _rangeEndAyah!.ayahNumber < ayahNumber) {
        _rangeEndAyah = null;
      }
    });
    await _showAyahPage(ayahNumber);
  }

  Future<void> _setRangeEnd(int ayahNumber) async {
    final start = _rangeStartAyah;
    if (start != null && ayahNumber < start.ayahNumber) {
      _showMessage('শেষ আয়াত শুরুর আয়াতের আগে হতে পারে না।');
      return;
    }
    setState(
      () => _rangeEndAyah = AyahRef(
        surahNumber: _selectedSurahNumber,
        ayahNumber: ayahNumber,
      ),
    );
    await _showAyahPage(ayahNumber);
  }

  Future<void> _showAyahPage(int ayahNumber) async {
    final ayah = await ref
        .read(quranRepositoryProvider)
        .loadAyah(
          surahNumber: _selectedSurahNumber,
          ayahNumber: ayahNumber,
          translationResourceId: ref.read(quranTranslationResourceIdProvider),
        );
    if (!mounted || ayah == null || ayah.pageNumber == _selectedPage) return;
    _turnPage(ayah.pageNumber);
  }

  Future<void> _startSession(HifzSessionConfig config) async {
    try {
      await ref.read(hifzSessionControllerProvider.notifier).start(config);
    } on ArgumentError catch (error) {
      debugPrint('Invalid Hifz range: $error');
      if (!mounted) return;
      _showMessage('নির্বাচিত আয়াত রেঞ্জটি সঠিক নয়।');
    }
  }

  Future<void> _resumeSaved() async {
    try {
      await ref.read(hifzSessionControllerProvider.notifier).resume();
    } catch (error, stackTrace) {
      debugPrint('Hifz resume failed: $error');
      debugPrintStack(stackTrace: stackTrace);
      if (!mounted) return;
      _showMessage('আগের হিফজ সেশনটি চালু করা যায়নি।');
    }
  }

  Future<void> _followActiveAyah(String ayahKey) async {
    if (_lastFollowedAyahKey == ayahKey) return;
    _lastFollowedAyahKey = ayahKey;

    final parts = ayahKey.split(':');
    if (parts.length != 2) return;
    final surahNumber = int.tryParse(parts[0]);
    final ayahNumber = int.tryParse(parts[1]);
    if (surahNumber != _selectedSurahNumber || ayahNumber == null) return;

    final ayah = await ref
        .read(quranRepositoryProvider)
        .loadAyah(
          surahNumber: surahNumber!,
          ayahNumber: ayahNumber,
          translationResourceId: ref.read(quranTranslationResourceIdProvider),
        );
    if (!mounted || ayah == null || ayah.pageNumber == _selectedPage) return;

    setState(() {
      _selectedPage = ayah.pageNumber;
      _pageFuture = _loadPage(ayah.pageNumber);
    });
  }

  Future<void> _alignToSession(HifzSessionConfig config) async {
    final surahs = await ref.read(quranSurahListProvider.future);
    final surah = _findSurah(surahs, config.start.surahNumber);
    final ayah = await ref
        .read(quranRepositoryProvider)
        .loadAyah(
          surahNumber: config.start.surahNumber,
          ayahNumber: config.start.ayahNumber,
          translationResourceId: ref.read(quranTranslationResourceIdProvider),
        );
    if (!mounted) return;

    setState(() {
      _selectedSurahNumber = surah.number;
      _selectedPage = ayah?.pageNumber ?? surah.pageStart;
      _rangeStartAyah = config.start;
      _rangeEndAyah = config.end;
      _pattern = HifzPatternSelection(
        ayahRepeatCount: config.preset.ayahRepeatCount,
        combinedRepeatCount: config.preset.combinedRepeatCount,
        finalRangeRepeatCount: config.preset.finalRangeRepeatCount,
      );
      _pageFuture = _loadPage(_selectedPage);
    });
  }

  Future<void> _playWord(QuranAyah ayah, QuranWord word) async {
    try {
      await ref.read(readerAudioActionsProvider).playWord(ayah, word);
    } on ReaderAudioUnavailableException catch (error) {
      if (!mounted) return;
      _showMessage(error.message);
    } catch (error, stackTrace) {
      debugPrint('Hifz word audio failed: $error');
      debugPrintStack(stackTrace: stackTrace);
      if (!mounted) return;
      _showMessage('শব্দের অডিও চালানো যায়নি।');
    }
  }

  Future<void> _showWordDetails(QuranAyah ayah, QuranWord word) {
    return showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (context) => WordDetailsSheet(
        target: StudyTarget.word(
          surahNumber: ayah.surahNumber,
          ayahNumber: ayah.ayahNumber,
          wordPosition: word.position,
        ),
        word: word,
        controller: ref.read(studyControllerProvider),
      ),
    );
  }

  void _showMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  QuranSurahSummary _findSurah(List<QuranSurahSummary> surahs, int number) {
    return surahs.firstWhere(
      (item) => item.number == number,
      orElse: () => surahs.first,
    );
  }
}

class _HifzPageControls extends StatelessWidget {
  const _HifzPageControls({
    required this.page,
    required this.showTools,
    required this.onPrevious,
    required this.onTools,
    required this.onNext,
  });

  final int page;
  final bool showTools;
  final VoidCallback? onPrevious;
  final VoidCallback? onTools;
  final VoidCallback? onNext;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: SizedBox(
        height: 48,
        child: Stack(
          alignment: Alignment.center,
          children: [
            Align(
              alignment: Alignment.centerLeft,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    tooltip: 'Previous Mushaf page',
                    onPressed: onPrevious,
                    icon: const Icon(Icons.chevron_right_rounded),
                  ),
                  Text('Page $page'),
                ],
              ),
            ),
            if (showTools)
              IconButton.filled(
                key: const ValueKey('hifz-tools'),
                tooltip: 'Expand Audio & Hifz',
                onPressed: onTools,
                alignment: Alignment.center,
                padding: EdgeInsets.zero,
                style: IconButton.styleFrom(
                  fixedSize: const Size.square(48),
                  backgroundColor: scheme.primary,
                  foregroundColor: scheme.onPrimary,
                  disabledBackgroundColor: scheme.primary.withValues(alpha: .4),
                  disabledForegroundColor: scheme.onPrimary.withValues(
                    alpha: .7,
                  ),
                ),
                icon: const Icon(Icons.keyboard_arrow_up_rounded, size: 28),
              ),
            Align(
              alignment: Alignment.centerRight,
              child: IconButton(
                tooltip: 'Next Mushaf page',
                onPressed: onNext,
                icon: const Icon(Icons.chevron_left_rounded),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CompactSurahSelector extends StatelessWidget {
  const _CompactSurahSelector({
    required this.surah,
    required this.page,
    required this.onTap,
  });

  final QuranSurahSummary surah;
  final int page;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
      child: Material(
        color: colorScheme.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: BorderSide(color: colorScheme.outlineVariant),
        ),
        child: InkWell(
          key: const ValueKey('hifz-surah-selector'),
          borderRadius: BorderRadius.circular(14),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
            child: Row(
              children: [
                Icon(Icons.menu_book_rounded, color: colorScheme.primary),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    '${surah.nameEnglish} · Juz ${surah.juzStart} · Page $page',
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                const Icon(Icons.keyboard_arrow_down_rounded),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
