import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../data/bundled_chapter_audio_source.dart';
import '../data/bundled_reciter_catalog_source.dart';
import '../domain/chapter_audio_source.dart';
import '../domain/reciter_catalog_source.dart';

final reciterAudioAssetBundleProvider = Provider<AssetBundle>((ref) {
  return rootBundle;
});

final reciterCatalogSourceProvider = Provider<ReciterCatalogSource>((ref) {
  return BundledReciterCatalogSource(
    bundle: ref.watch(reciterAudioAssetBundleProvider),
  );
});

final chapterAudioSourceProvider = Provider<ChapterAudioSource>((ref) {
  return BundledChapterAudioSource(
    bundle: ref.watch(reciterAudioAssetBundleProvider),
  );
});
