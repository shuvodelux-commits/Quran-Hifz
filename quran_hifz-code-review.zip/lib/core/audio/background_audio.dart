import 'package:just_audio_background/just_audio_background.dart';

typedef BackgroundAudioInitializer = Future<void> Function();

Future<void> initializeBackgroundAudio({
  BackgroundAudioInitializer? initializer,
}) {
  return (initializer ?? _initializeJustAudioBackground)();
}

Future<void> _initializeJustAudioBackground() {
  return JustAudioBackground.init(
    androidNotificationChannelId: 'com.quranhifz.audio',
    androidNotificationChannelName: 'Quran playback',
    androidNotificationIcon: 'drawable/ic_stat_quran',
    androidNotificationOngoing: true,
  );
}
