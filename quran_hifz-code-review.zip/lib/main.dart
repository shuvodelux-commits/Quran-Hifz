import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'core/audio/background_audio.dart';

import 'app/quran_hifz_app.dart';

Widget buildRootApp() {
  return const ProviderScope(child: QuranHifzApp());
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeBackgroundAudio();
  runApp(buildRootApp());
}
